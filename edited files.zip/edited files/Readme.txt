MainCamera.cs should be attached to the camera in Unity.

The Daniel Character moves crates by attaching a rigidbody to crates and Daniel, and setting off an animation. Daniel is kinematic, the crates are not.

The mayor (Richard in all black) calls for help when a room is closed off, when he is locked in and out of the room.

Three new implemented affordances:
	Flexing Arms
	Pushing Crates
	Karate Greet

Their are two major arcs, when there is a town meeting, all three characters come to the center point and interact with each other, and they also have individual story arcs.

The room can be blocked by using the up and down arrow keys to move a wall.